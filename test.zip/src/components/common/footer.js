import { Footer } from "../../styles/common/footer.styles";

const DashboardFooter = ()=>{

  return(
    <Footer>
        ⓒ 2023. JHJ all rights reserved
    </Footer>
  );
}

export default DashboardFooter;