// // import './d04cssFile.css'

// function CssFile(){
//   return(
//     <>
//     <h1>
//       css파일을 따로 만들어서 컴포넌트에 적용시켜봄
//     </h1>
//     <p>
//       css파일을 만들어서 해당 경로를 사용하고자 하는
//       js 안에 import해주면 된다.
//     </p>
//     </>
//   )
// }

// export default CssFile;